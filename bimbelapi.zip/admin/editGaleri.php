<?php
// Menghubungkan dengan file koneksi.php
include 'koneksi.php';

// Mengecek apakah ada data yang dikirim melalui metode POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Mengambil nilai yang dikirim melalui form
    $idGaleri = $_POST['id_galeri'];
    $namaFoto = $_POST['nama_foto'];
    $deskripsi = $_POST['deskripsi'];

    // Mengambil informasi file yang diunggah
    $namaFile = $_FILES['foto']['name'];
    $ukuranFile = $_FILES['foto']['size'];
    $tmpFile = $_FILES['foto']['tmp_name'];
    $error = $_FILES['foto']['error'];

    // Menentukan lokasi penyimpanan file yang diunggah
    $lokasiFile = '../assets/img/galeri/' . $namaFile;

    // Memeriksa apakah file berhasil diunggah
    if ($error === 0) {
        // Memindahkan file yang diunggah ke lokasi penyimpanan
        move_uploaded_file($tmpFile, $lokasiFile);

        // Update data galeri berdasarkan id_galeri
        $query = "UPDATE galeri SET nama_foto='$namaFoto', deskripsi='$deskripsi', foto='$namaFile' WHERE id_galeri='$idGaleri'";
        $result = mysqli_query($koneksi, $query);

        if ($result) {
            // Jika data berhasil diupdate, arahkan pengguna kembali ke halaman galeri.php
            header('Location: galeri.php');
            exit();
        } else {
            // Jika terjadi kesalahan saat mengupdate data, tampilkan pesan error
            echo "Error: " . mysqli_error($koneksi);
        }
    } else {
        // Jika terjadi kesalahan saat mengunggah file, tampilkan pesan error
        echo "Error uploading file.";
    }
} else {
    // Mengambil id_galeri dari URL
    $idGaleri = $_GET['id_galeri'];

    // Query untuk mendapatkan data galeri berdasarkan id_galeri
    $query = "SELECT * FROM galeri WHERE id_galeri='$idGaleri'";
    $result = mysqli_query($koneksi, $query);

    // Memeriksa apakah data galeri dengan id_galeri yang diberikan ditemukan
    if (mysqli_num_rows($result) > 0) {
        // Mendapatkan data galeri
        $row = mysqli_fetch_assoc($result);
        $namaFoto = $row['nama_foto'];
        $deskripsi = $row['deskripsi'];
        $foto = $row['foto'];
    } else {
        // Jika data galeri tidak ditemukan, arahkan pengguna kembali ke halaman galeri.php
        header('Location: galeri.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<?php include 'header.php'; ?>

<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <?php include 'navbar.php'; ?>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light bg-transparent py-4 px-4">
                <div class="d-flex align-items-center">
                    <i class="fas fa-align-left primary-text fs-4 me-3" id="menu-toggle"></i>
                </div>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle second-text fw-bold" href="#" id="navbarDropdown"
                                role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user me-2"></i>Amy NurRahayu
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#">Profile</a></li>
                                <li><a class="dropdown-item" href="#">Settings</a></li>
                                <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>

            <div class="container-fluid px-4 right">
                <div class="row my-5 justify-content-center">
                    <h3 class=" mb-3 fw-bold">Edit Galeri</h3>

                    <div class="col-6">
                        <a class="btn btn-success mb-3" href="galeri.php" type="button">Kembali</a>
                        <form action="" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="id_galeri" value="<?php echo $idGaleri; ?>">
                            <div class="mb-3">
                                <label for="formFile" class="form-label">Tambah Foto</label>
                                <input required class="form-control" type="file" id="formFile" name="foto">
                            </div>
                            <div class="mb-3">
                                <label for="exampleFormControlInput1" class="form-label">Nama</label>
                                <input required type="text" class="form-control" id="exampleFormControlInput1"
                                    placeholder="name@example.com" name="nama_foto" value="<?php echo $namaFoto; ?>">
                            </div>
                            <div class="mb-3">
                                <label for="exampleFormControlTextarea1" class="form-label">Deskripsi</label>
                                <textarea required class="form-control" id="exampleFormControlTextarea1" rows="3"
                                    name="deskripsi"><?php echo $deskripsi; ?></textarea>
                            </div>
                            <button class="btn btn-success" type="submit" name="submit">Simpan</button>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- /#page-content-wrapper -->
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    var el = document.getElementById("wrapper");
    var toggleButton = document.getElementById("menu-toggle");

    toggleButton.onclick = function() {
        el.classList.toggle("toggled");
    };
    </script>
</body>

</html>